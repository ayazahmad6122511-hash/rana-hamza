
import 'package:flutter/material.dart';

void main() => runApp(const BuildTrackApp());

const navy = Color(0xFF102A43);
const blue = Color(0xFF2563EB);
const teal = Color(0xFF0F9D8A);
const bg = Color(0xFFF3F6FA);

class BuildTrackApp extends StatelessWidget {
  const BuildTrackApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BuildTrack',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(seedColor: blue),
        fontFamily: 'Roboto',
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;
  final pages = const [
    DashboardPage(),
    ProjectsPage(),
    LabourPage(),
    AttendancePage(),
    WagesPage(),
    PurchasesPage(),
    FinancePage(),
    ReportsPage(),
  ];
  final labels = ['Dashboard', 'Projects / Sites', 'Labour', 'Attendance',
    'Daily Wages', 'Site Purchases', 'Income & Expenses', 'Reports'];
  final icons = [Icons.dashboard_rounded, Icons.apartment_rounded,
    Icons.groups_rounded, Icons.fact_check_rounded, Icons.payments_rounded,
    Icons.shopping_cart_rounded, Icons.account_balance_wallet_rounded,
    Icons.analytics_rounded];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= 760;
      return Scaffold(
        appBar: AppBar(
          backgroundColor: navy,
          foregroundColor: Colors.white,
          title: Row(children: [
            Container(width: 36, height: 36,
              decoration: BoxDecoration(color: Colors.white.withOpacity(.14),
                borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.construction_rounded, color: Colors.white)),
            const SizedBox(width: 10),
            const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('BUILDTRACK', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
              Text('Construction Site Management', style: TextStyle(fontSize: 11, color: Colors.white70)),
            ]),
          ]),
          actions: [
            if (wide) const Padding(padding: EdgeInsets.symmetric(horizontal: 16),
              child: Center(child: Text('Semester Project  •  2026'))),
            IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none_rounded)),
          ],
        ),
        drawer: wide ? null : Drawer(child: SafeArea(child: ListView(
          children: [
            const ListTile(title: Text('BUILDTRACK', style: TextStyle(fontWeight: FontWeight.bold))),
            ...List.generate(labels.length, (i) => ListTile(
              leading: Icon(icons[i]), title: Text(labels[i]),
              selected: selected == i, onTap: () { setState(() => selected = i); Navigator.pop(context); },
            )),
          ],
        ))),
        body: Row(children: [
          if (wide) Container(width: 225, color: navy, child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Padding(padding: EdgeInsets.all(18), child: Text('WORKSPACE',
                style: TextStyle(color: Colors.white54, fontSize: 11, letterSpacing: 1.5))),
              ...List.generate(labels.length, (i) => InkWell(
                onTap: () => setState(() => selected = i),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
                  decoration: BoxDecoration(color: selected == i ? blue : Colors.transparent,
                    borderRadius: BorderRadius.circular(10)),
                  child: Row(children: [
                    Icon(icons[i], color: Colors.white, size: 19),
                    const SizedBox(width: 12),
                    Expanded(child: Text(labels[i], style: const TextStyle(color: Colors.white, fontSize: 13))),
                  ]),
                ),
              )),
              const Spacer(),
              const Padding(padding: EdgeInsets.all(16), child: Text('PLAN • TRACK • BUILD',
                style: TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1.2))),
            ],
          )),
          Expanded(child: pages[selected]),
        ]),
      );
    });
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(padding: const EdgeInsets.all(18), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(children: [
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Overview', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: navy)),
            SizedBox(height: 4), Text('Your sites, workforce and finances at a glance',
              style: TextStyle(color: Colors.blueGrey)),
          ])),
          FilledButton.icon(onPressed: () => _showAdd(context, 'Project'),
            icon: const Icon(Icons.add), label: const Text('New project')),
        ]),
        const SizedBox(height: 18),
        const Wrap(spacing: 12, runSpacing: 12, children: [
          StatCard(title: 'Active Projects', value: '05', caption: '2 nearing completion', icon: Icons.apartment, color: blue),
          StatCard(title: 'Total Income', value: 'Rs 12.45M', caption: 'Current month', icon: Icons.trending_up, color: teal),
          StatCard(title: 'Total Expenses', value: 'Rs 9.32M', caption: 'Current month', icon: Icons.receipt_long, color: Color(0xFFEA580C)),
          StatCard(title: 'Net Profit', value: 'Rs 3.13M', caption: '25.1% margin', icon: Icons.account_balance, color: Color(0xFF7C3AED)),
        ]),
        const SizedBox(height: 18),
        const SectionCard(title: 'Project Snapshot', trailing: 'View all', child: ProjectTable()),
        const SizedBox(height: 18),
        LayoutBuilder(builder: (context, c) {
          final two = c.maxWidth > 700;
          final cards = [
            const SectionCard(title: 'Monthly Cash Flow', child: MiniBarChart()),
            const SectionCard(title: 'Workforce Today', child: WorkforceSummary()),
          ];
          return two ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: cards[0]), const SizedBox(width: 14), Expanded(child: cards[1])
          ]) : Column(children: [cards[0], const SizedBox(height: 14), cards[1]]);
        }),
        const SizedBox(height: 18),
        const SectionCard(title: 'Recent Activity', child: ActivityList()),
      ],
    ));
  }
}

class StatCard extends StatelessWidget {
  final String title, value, caption;
  final IconData icon;
  final Color color;
  const StatCard({super.key, required this.title, required this.value,
    required this.caption, required this.icon, required this.color});
  @override
  Widget build(BuildContext context) => SizedBox(width: 245, child: Card(
    elevation: 0, color: Colors.white, shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0xFFE4EAF1))),
    child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [
      Container(width: 48, height: 48, decoration: BoxDecoration(color: color.withOpacity(.12),
        borderRadius: BorderRadius.circular(13)), child: Icon(icon, color: color)),
      const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
        children: [Text(title, style: const TextStyle(color: Colors.blueGrey, fontSize: 12)),
          const SizedBox(height: 5), Text(value, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 19)),
          Text(caption, style: const TextStyle(color: Colors.grey, fontSize: 10))]),
      ),
    ])),
  ));
}

class SectionCard extends StatelessWidget {
  final String title;
  final String? trailing;
  final Widget child;
  const SectionCard({super.key, required this.title, required this.child, this.trailing});
  @override
  Widget build(BuildContext context) => Card(
    elevation: 0, color: Colors.white, shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0xFFE4EAF1))),
    child: Padding(padding: const EdgeInsets.all(16), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
          if (trailing != null) Text(trailing!, style: const TextStyle(color: blue, fontSize: 12))]),
        const SizedBox(height: 14), child,
      ],
    )),
  );
}

class ProjectTable extends StatelessWidget {
  const ProjectTable({super.key});
  @override
  Widget build(BuildContext context) {
    final data = [
      ['DHA Villa – Block C', 'Multan', 'Rs 2.45M', '68%', 'In progress'],
      ['Gulberg Residence', 'Multan', 'Rs 3.10M', '82%', 'In progress'],
      ['Commercial Plaza', 'Bosan Road', 'Rs 1.80M', '42%', 'Planning'],
      ['Farmhouse Project', 'Near Multan', 'Rs 0.90M', '25%', 'In progress'],
    ];
    return SingleChildScrollView(scrollDirection: Axis.horizontal, child: DataTable(
      headingRowHeight: 34, dataRowMinHeight: 45, dataRowMaxHeight: 55,
      columns: const [DataColumn(label: Text('Project')), DataColumn(label: Text('Location')),
        DataColumn(label: Text('Budget')), DataColumn(label: Text('Progress')), DataColumn(label: Text('Status'))],
      rows: data.map((r) => DataRow(cells: [
        DataCell(Text(r[0])), DataCell(Text(r[1])), DataCell(Text(r[2])),
        DataCell(SizedBox(width: 90, child: Column(mainAxisAlignment: MainAxisAlignment.center,
          children: [LinearProgressIndicator(value: int.parse(r[3].replaceAll('%',''))/100,
            color: teal, backgroundColor: teal.withOpacity(.12)), const SizedBox(height: 4), Text(r[3], style: const TextStyle(fontSize: 10))]))),
        DataCell(Chip(label: Text(r[4], style: const TextStyle(fontSize: 10)),
          backgroundColor: r[4] == 'Planning' ? Colors.orange.shade50 : Colors.green.shade50)),
      ])).toList(),
    ));
  }
}

class MiniBarChart extends StatelessWidget {
  const MiniBarChart({super.key});
  @override
  Widget build(BuildContext context) => SizedBox(height: 180, child: Row(
    crossAxisAlignment: CrossAxisAlignment.end, mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: List.generate(5, (i) {
      final income = [90, 125, 105, 150, 130][i].toDouble();
      final expense = [65, 90, 85, 105, 95][i].toDouble();
      return Column(mainAxisAlignment: MainAxisAlignment.end, children: [
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Container(width: 17, height: income, decoration: BoxDecoration(color: teal, borderRadius: BorderRadius.circular(4))),
          const SizedBox(width: 5),
          Container(width: 17, height: expense, decoration: BoxDecoration(color: const Color(0xFFF97316), borderRadius: BorderRadius.circular(4))),
        ]),
        const SizedBox(height: 8), Text('W${i+1}', style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
      ]);
    }),
  ));
}

class WorkforceSummary extends StatelessWidget {
  const WorkforceSummary({super.key});
  @override
  Widget build(BuildContext context) => Column(children: [
    Row(children: const [Expanded(child: Text('Present today', style: TextStyle(color: Colors.blueGrey))),
      Text('42 / 48', style: TextStyle(fontWeight: FontWeight.bold))]),
    const SizedBox(height: 10), const LinearProgressIndicator(value: .875, minHeight: 10, color: teal),
    const SizedBox(height: 18),
    const Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
      WorkforceMetric('Present', '42', teal), WorkforceMetric('Absent', '4', Colors.red),
      WorkforceMetric('On leave', '2', Colors.orange),
    ]),
    const SizedBox(height: 12), const Divider(),
    const Row(children: [Icon(Icons.payments_outlined, color: blue), SizedBox(width: 8),
      Expanded(child: Text('Estimated daily wages')), Text('Rs 48,500', style: TextStyle(fontWeight: FontWeight.bold))]),
  ]);
}
class WorkforceMetric extends StatelessWidget {
  final String title, value; final Color color;
  const WorkforceMetric(this.title, this.value, this.color, {super.key});
  @override Widget build(BuildContext context) => Column(children: [
    Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color)),
    Text(title, style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
  ]);
}

class ActivityList extends StatelessWidget {
  const ActivityList({super.key});
  @override Widget build(BuildContext context) => Column(children: const [
    ActivityRow(Icons.payments, 'Wages marked paid', 'DHA Villa • 6 workers', 'Today, 11:20 AM', teal),
    Divider(), ActivityRow(Icons.shopping_bag, 'Material purchase recorded', 'Cement • 40 bags', 'Today, 10:05 AM', Colors.orange),
    Divider(), ActivityRow(Icons.person_add_alt_1, 'New labour added', 'Gulberg Residence', 'Yesterday', blue),
  ]);
}
class ActivityRow extends StatelessWidget {
  final IconData icon; final String title, subtitle, time; final Color color;
  const ActivityRow(this.icon, this.title, this.subtitle, this.time, this.color, {super.key});
  @override Widget build(BuildContext context) => ListTile(contentPadding: EdgeInsets.zero,
    leading: CircleAvatar(backgroundColor: color.withOpacity(.12), child: Icon(icon, color: color)),
    title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
    subtitle: Text(subtitle), trailing: Text(time, style: const TextStyle(fontSize: 10, color: Colors.grey)));
}

class SimplePage extends StatelessWidget {
  final String title, description; final IconData icon;
  const SimplePage(this.title, this.description, this.icon, {super.key});
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.all(20),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: navy)),
      const SizedBox(height: 6), Text(description, style: const TextStyle(color: Colors.blueGrey)),
      const SizedBox(height: 20),
      SectionCard(title: '$title Overview', child: Column(children: [
        Icon(icon, size: 54, color: blue), const SizedBox(height: 12),
        Text('Manage $title from one place.', style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8), const Text('This module is ready to connect with a local database.'),
        const SizedBox(height: 16), FilledButton.icon(onPressed: () => _showAdd(context, title),
          icon: const Icon(Icons.add), label: Text('Add $title entry')),
      ])),
    ]));
}
class ProjectsPage extends StatelessWidget { const ProjectsPage({super.key}); @override Widget build(BuildContext c) => const SimplePage('Projects / Sites','Create projects, assign sites and monitor progress.',Icons.apartment); }
class LabourPage extends StatelessWidget { const LabourPage({super.key}); @override Widget build(BuildContext c) => const SimplePage('Labour Management','Maintain labour records and worker details.',Icons.groups); }
class AttendancePage extends StatelessWidget { const AttendancePage({super.key}); @override Widget build(BuildContext c) => const SimplePage('Attendance','Record daily worker attendance and in/out time.',Icons.fact_check); }
class WagesPage extends StatelessWidget { const WagesPage({super.key}); @override Widget build(BuildContext c) => const SimplePage('Daily Wages','Track daily wages and payment status.',Icons.payments); }
class PurchasesPage extends StatelessWidget { const PurchasesPage({super.key}); @override Widget build(BuildContext c) => const SimplePage('Site Purchases','Record construction material and site purchases.',Icons.shopping_cart); }
class FinancePage extends StatelessWidget { const FinancePage({super.key}); @override Widget build(BuildContext c) => const SimplePage('Income & Expenses','Track client payments, expenses and cash flow.',Icons.account_balance_wallet); }
class ReportsPage extends StatelessWidget { const ReportsPage({super.key}); @override Widget build(BuildContext c) => const SimplePage('Reports & Profit/Loss','View project summaries, financial reports and profit/loss.',Icons.analytics); }

void _showAdd(BuildContext context, String entity) {
  final name = TextEditingController();
  final amount = TextEditingController();
  showDialog(context: context, builder: (_) => AlertDialog(
    title: Text('Add $entity'),
    content: Column(mainAxisSize: MainAxisSize.min, children: [
      TextField(controller: name, decoration: const InputDecoration(labelText: 'Name / Description')),
      const SizedBox(height: 10),
      TextField(controller: amount, keyboardType: TextInputType.number,
        decoration: const InputDecoration(labelText: 'Amount / Budget (optional)')),
    ]),
    actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
      FilledButton(onPressed: () {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$entity form submitted (demo).')));
      }, child: const Text('Save'))],
  ));
}
