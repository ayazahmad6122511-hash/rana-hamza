# BuildTrack – Construction Site Management (Flutter Semester Project)

## Features in this starter
- Responsive dashboard with project KPIs
- Project/site overview and progress
- Labour, attendance and daily wages modules
- Site purchases and income/expense modules
- Reports and profit/loss module
- Add-entry demo forms
- No external UI/chart packages (keeps dependencies small)

## Run
1. Install Flutter SDK and Android Studio.
2. Extract this folder.
3. Open terminal in this folder and run:
   `flutter pub get`
   `flutter run`
4. Build APK:
   `flutter build apk --release`
5. APK path:
   `build/app/outputs/flutter-apk/app-release.apk`

## Important
This is a UI/demo starter. The sample numbers are dummy data. Persistent database, authentication,
and full CRUD can be added next (e.g. SQLite). Do not submit demo figures as real data.
